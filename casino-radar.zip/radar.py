#!/usr/bin/env python3
"""Casino radar: rule-based early warning for casino stories. No AI calls.

Every run (every 30 min on GitHub Actions) does, in parallel and inside a time budget:
  forum      BitcoinTalk scam + gambling boards, new threads naming casinos
  freezes    USDT/USDC freeze batches across chains (Stablescan)
  tokens     casino token crashes (GeckoTerminal)
  wallets    casino hot wallets, bankrolls and parked hack money (Blockscout, TronGrid)
  sites      priority casinos every run, plus every domain on the Anjouan and Curacao
             registers in rotation; outages grouped by licence (Betmode pattern)
  news       local-language Google News, brand and generic queries, in rotation
  registers  Anjouan register diff (new / removed licences and domains, mirror
             brands under a new company) and Curacao certificate crawl
  pages      regulator enforcement pages: new links
Alerts go to Telegram. Low-priority items go into a morning digest.
"""
import argparse
import datetime as dt
import hashlib
import html
import json
import os
import re
import sys
import threading
import time
import urllib.parse
from concurrent.futures import ThreadPoolExecutor
from email.utils import parsedate_to_datetime

import requests
import yaml

UA = "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0 Safari/537.36"
TIMEOUT = 7
HIGH, LOW = "HIGH", "LOW"
LOCK = threading.Lock()

BLOCKSCOUT = {
    "eth": "https://eth.blockscout.com",
    "base": "https://base.blockscout.com",
    "arbitrum": "https://arbitrum.blockscout.com",
    "optimism": "https://optimism.blockscout.com",
    "etherlink": "https://explorer.etherlink.com",
    "gnosis": "https://gnosis.blockscout.com",
}
STABLES = {"USDT", "USDC", "DAI", "USDE", "PYUSD", "USDS", "USDSM", "FDUSD", "USD1", "USDT0", "TUSD"}
TRON_USDT = "TR7NHqjeKQxGTCi8q8ZY4pL8otSzgjLj6t"
WTRX = "TNUC9Qb1rRpS5CbWLmNMxXBjyFoydXjWFR"


# ---------------------------------------------------------------- basics
def now():
    return dt.datetime.now(dt.timezone.utc)


def iso(t):
    return t.strftime("%Y-%m-%dT%H:%M:%SZ")


def parse_iso(s):
    return dt.datetime.fromisoformat(s.replace("Z", "+00:00"))


def due(st, key, t, minutes):
    """True if a periodic job is due; records the run time."""
    last = st.get(key)
    if last and t - parse_iso(last) < dt.timedelta(minutes=minutes):
        return False
    st[key] = iso(t)
    return True


def norm_domain(d):
    d = d.strip().lower()
    d = re.sub(r"^https?://", "", d).split("/")[0]
    return d[4:] if d.startswith("www.") else d


def rotate(items, st, key, n):
    """Return the next n items from a list, wrapping around, and move the cursor."""
    if not items:
        return []
    i = st.get(key, 0) % len(items)
    out = (items[i:] + items[:i])[:n]
    st[key] = (i + len(out)) % len(items)
    return out


class Budget:
    def __init__(self, seconds):
        self.end = time.time() + seconds

    def left(self):
        return self.end - time.time()

    def ok(self, need=0):
        return self.left() > need


class Http:
    def __init__(self):
        self.s = requests.Session()
        self.s.headers["User-Agent"] = UA
        a = requests.adapters.HTTPAdapter(pool_connections=64, pool_maxsize=64, max_retries=0)
        self.s.mount("https://", a)
        self.s.mount("http://", a)

    def get(self, url, **kw):
        kw.setdefault("timeout", TIMEOUT)
        return self.s.get(url, **kw)

    def json(self, url, **kw):
        r = self.get(url, **kw)
        r.raise_for_status()
        return r.json()

    def post(self, url, **kw):
        kw.setdefault("timeout", TIMEOUT)
        return self.s.post(url, **kw)

    def snippet(self, url, limit=60000):
        """GET a page but read at most `limit` bytes (cheap site checks)."""
        r = self.s.get(url, timeout=TIMEOUT, stream=True, allow_redirects=True)
        chunks, size = [], 0
        try:
            for c in r.iter_content(8192):
                chunks.append(c)
                size += len(c)
                if size >= limit:
                    break
        finally:
            r.close()
        enc = r.encoding or "utf-8"
        r._snip = b"".join(chunks).decode(enc, "replace")
        return r


class Alert:
    def __init__(self, level, check, key, text):
        self.level, self.check, self.key, self.text = level, check, key, text

    def __repr__(self):
        return f"[{self.level}] {self.check}: {self.text}"


QUIET = os.environ.get("RADAR_QUIET") == "1"
ERRORS = {}


def log(*a):
    """In quiet mode (public repo) only error counts are printed, never names,
    addresses or alert text."""
    msg = " ".join(str(x) for x in a)
    if QUIET:
        k = msg.split(":")[0].split(" ")[0]
        with LOCK:
            ERRORS[k] = ERRORS.get(k, 0) + 1
    else:
        print(msg, file=sys.stderr)


# ---------------------------------------------------------------- tokens
def check_tokens(cfg, state, http, t, budget=None):
    alerts = []
    rules = cfg.get("token_rules", {})
    drop6, drop24 = rules.get("drop_6h_pct", 20), rules.get("drop_24h_pct", 25)
    st = state.setdefault("tokens", {})
    by_net = {}
    for tok in cfg.get("tokens", []):
        by_net.setdefault(tok["network"], []).append(tok)
    for net, toks in by_net.items():
        for i in range(0, len(toks), 30):
            part = toks[i:i + 30]
            try:
                data = http.json(f"https://api.geckoterminal.com/api/v2/networks/{net}/pools/multi/"
                                 + ",".join(x["pool"] for x in part))["data"]
            except Exception as e:
                log(f"tokens {net}: {e}")
                continue
            found = {d["attributes"]["address"].lower(): d["attributes"] for d in data}
            for tok in part:
                a = found.get(tok["pool"].lower())
                if not a:
                    continue
                ch = a.get("price_change_percentage") or {}
                h6, h24 = float(ch.get("h6") or 0), float(ch.get("h24") or 0)
                price = a.get("base_token_price_usd")
                last = st.get(tok["name"], {})
                rec = {"price": price, "h24": h24, "at": iso(t)}
                if last.get("alerted"):
                    rec["alerted"] = last["alerted"]
                st[tok["name"]] = rec
                if h6 <= -drop6 or h24 <= -drop24:
                    if last.get("alerted") and t - parse_iso(last["alerted"]) < dt.timedelta(hours=12):
                        continue
                    rec["alerted"] = iso(t)
                    alerts.append(Alert(HIGH, "token", f"tok:{tok['name']}:{t:%Y%m%d%H}",
                        f"TOKEN CRASH: {tok['name']} down {h6:.0f}% in 6h, {h24:.0f}% in 24h "
                        f"(price ${float(price):.3g}). https://www.geckoterminal.com/{net}/pools/{tok['pool']}"))
    return alerts


# ---------------------------------------------------------------- wallets
def wallet_usd_blockscout(http, chain, address):
    base = BLOCKSCOUT[chain]
    info = http.json(f"{base}/api/v2/addresses/{address}")
    rate = float(info.get("exchange_rate") or 0)
    native = float(info.get("coin_balance") or 0) / 1e18 * rate
    total, parts = native, ({"native": native} if native > 1 else {})
    for b in http.json(f"{base}/api/v2/addresses/{address}/token-balances"):
        tok = b.get("token") or {}
        sym = (tok.get("symbol") or "").upper()
        dec = int(tok.get("decimals") or 18)
        amt = float(b.get("value") or 0) / 10 ** dec
        holders = int(tok.get("holders_count") or tok.get("holders") or 0)
        if sym in STABLES and holders > 1000:
            usd = amt
        elif tok.get("exchange_rate") and holders > 1000:
            usd = amt * float(tok["exchange_rate"])
        else:
            continue  # unpriced, spam or fake token
        if usd > 1:
            parts[sym] = parts.get(sym, 0) + usd
            total += usd
    return total, parts


def wallet_usd_tron(http, address, trx_usd):
    d = (http.json(f"https://api.trongrid.io/v1/accounts/{address}").get("data") or [{}])
    d = d[0] if d else {}
    trx = float(d.get("balance") or 0) / 1e6
    usdt = 0.0
    for x in d.get("trc20") or []:
        if TRON_USDT in x:
            usdt = float(x[TRON_USDT]) / 1e6
    parts = {"TRX": trx * trx_usd, "USDT": usdt}
    return parts["TRX"] + usdt, {k: v for k, v in parts.items() if v > 1}


def trx_price(http):
    try:
        d = http.json(f"https://api.geckoterminal.com/api/v2/simple/networks/tron/token_price/{WTRX}")
        return float(list(d["data"]["attributes"]["token_prices"].values())[0])
    except Exception:
        return 0.0


def merge_private(cfg):
    """Private watchlists come from GitHub secrets so a public repo never shows them.
    RADAR_PRIVATE_YAML: YAML whose lists are added to the config's lists.
    RADAR_WALLETS_CSV: extra lines in wallets.csv format."""
    raw = os.environ.get("RADAR_PRIVATE_YAML")
    if raw:
        try:
            extra = yaml.safe_load(raw) or {}
        except Exception:
            log("private: unreadable RADAR_PRIVATE_YAML")
            extra = {}

        def merge(a, b):
            for k, v in b.items():
                if isinstance(v, list) and isinstance(a.get(k), list):
                    a[k] = a[k] + v
                elif isinstance(v, dict) and isinstance(a.get(k), dict):
                    merge(a[k], v)
                else:
                    a[k] = v
        merge(cfg, extra)
    cfg["_wallets_csv_extra"] = os.environ.get("RADAR_WALLETS_CSV", "")
    return cfg


def load_wallets(cfg, state, base_dir="."):
    """Config wallets + wallets.csv (name,chain,address,kind,min_usd) + auto-discovered."""
    ws = list(cfg.get("wallets", []))
    path = os.path.join(base_dir, cfg.get("wallets_csv", "wallets.csv"))
    lines = open(path, encoding="utf-8").read().splitlines() if os.path.exists(path) else []
    lines += (cfg.get("_wallets_csv_extra") or "").splitlines()
    if lines:
        for line in lines:
            line = line.strip()
            if not line or line.startswith("#") or line.lower().startswith("name,"):
                continue
            p = [x.strip() for x in line.split(",")]
            if len(p) >= 3:
                w = {"name": p[0], "chain": p[1].lower(), "address": p[2], "kind": (p[3] if len(p) > 3 and p[3] else "hot")}
                if len(p) > 4 and p[4]:
                    w["min_usd"] = float(p[4])
                ws.append(w)
    pinned = {(w["chain"], w["address"].lower()) for w in ws}
    disc = [dict(v, address=k.split(":", 1)[1], chain=k.split(":", 1)[0], kind="hot", discovered=True)
            for k, v in sorted(state.get("discovered_wallets", {}).items())
            if (k.split(":", 1)[0], k.split(":", 1)[1]) not in pinned]
    return ws, disc


def check_wallets(cfg, state, http, t, budget=None, base_dir="."):
    alerts = []
    st = state.setdefault("wallets", {})
    pinned, disc = load_wallets(cfg, state, base_dir)
    batch = pinned + rotate(disc, state.setdefault("cursors", {}), "wallets", cfg.get("wallets_per_run", 60))
    trx_usd = trx_price(http) if any(w["chain"] == "tron" for w in batch) else 0

    def one(w):
        if budget and not budget.ok(3):
            return w, None, "budget"
        try:
            if w["chain"] == "tron":
                return w, wallet_usd_tron(http, w["address"], trx_usd), None
            if w["chain"] not in BLOCKSCOUT:
                return w, None, "budget"  # polygon/bsc wallets are covered by the chain watcher
            return w, wallet_usd_blockscout(http, w["chain"], w["address"]), None
        except Exception as e:
            return w, None, e

    with ThreadPoolExecutor(10) as ex:
        results = list(ex.map(one, batch))
    for w, res, err in results:
        key = f"{w['chain']}:{w['address'].lower()}"
        if err or res is None:
            if err != "budget":
                log(f"wallet {w['name']}: {err}")
            continue
        usd, parts = res
        rec = st.get(key, {"hist": []})
        hist = [h for h in rec.get("hist", []) if t - parse_iso(h[0]) < dt.timedelta(hours=24)]
        prev = hist[-1][1] if hist else None
        peak = max([h[1] for h in hist] + [usd])
        hist.append([iso(t), round(usd, 2)])
        rec["hist"] = hist[-60:]
        st[key] = rec
        if prev is None:
            continue
        label = f"{w['name']} ({w['chain']} {w['address'][:8]}…{w['address'][-4:]})"
        parts_txt = ", ".join(f"{k} ${v:,.0f}" for k, v in sorted(parts.items(), key=lambda x: -x[1])[:4])
        link = (f"https://tronscan.org/#/address/{w['address']}" if w["chain"] == "tron"
                else f"{BLOCKSCOUT.get(w['chain'], '')}/address/{w['address']}")
        if w.get("kind") == "parked":
            moved = prev - usd
            if moved >= max(float(w.get("min_usd", 25000)), 0.05 * prev):
                alerts.append(Alert(HIGH, "wallet", f"w:{key}:{t:%Y%m%d%H}",
                    f"PARKED MONEY MOVED: {label} dropped ${moved:,.0f} (now ${usd:,.0f}). {parts_txt} {link}"))
        else:
            fall = peak - usd
            if peak > 0 and fall >= float(w.get("min_usd", 250000)) and fall / peak * 100 >= w.get("drop_pct", 60):
                if rec.get("alerted") and t - parse_iso(rec["alerted"]) < dt.timedelta(hours=6):
                    continue
                rec["alerted"] = iso(t)
                alerts.append(Alert(HIGH, "wallet", f"w:{key}:{t:%Y%m%d%H}",
                    f"WALLET DRAIN: {label} fell {fall / peak * 100:.0f}% in 24h, ${peak:,.0f} -> ${usd:,.0f}. "
                    f"{parts_txt} {link}"))
    return alerts


def discover_wallets(cfg, state, http, t, budget=None):
    """Weekly: find casino wallets that Blockscout labels (Etherscan-style tags).
    Deposit addresses are skipped; hot wallets and named wallets are kept."""
    if not due(state.setdefault("jobs", {}), "discover", t, cfg.get("discover_every_hours", 168) * 60):
        return []
    found = state.setdefault("discovered_wallets", {})
    before = len(found)
    skip = re.compile(r"deposit address|staking|token|deployer|competition|nft|airdrop|\.eth$", re.I)
    for chain in cfg.get("discover_chains", ["eth"]):
        base = BLOCKSCOUT[chain]
        for brand in cfg.get("wallet_brands", []):
            if budget and not budget.ok(5):
                state["jobs"].pop("discover", None)  # finish next run
                return []
            key = re.sub(r"\.(com|us|gg|io|bet|game)$", "", brand.lower()).replace(".", "")
            url = f"{base}/api/v2/search?q={urllib.parse.quote(brand)}"
            for _ in range(3):
                try:
                    r = http.json(url)
                except Exception as e:
                    log(f"discover {brand}: {e}")
                    break
                for x in r.get("items") or []:
                    name = ((x.get("metadata") or {}).get("name") or "")
                    a = x.get("address_hash")
                    if x.get("type") != "metadata_tag" or not a or skip.search(name):
                        continue
                    if key not in name.lower().replace(".", ""):
                        continue
                    found.setdefault(f"{chain}:{a.lower()}", {"name": name, "min_usd": 250000})
                npp = r.get("next_page_params")
                if not npp:
                    break
                url = f"{base}/api/v2/search?q={urllib.parse.quote(brand)}&{urllib.parse.urlencode(npp)}"
    added = len(found) - before
    return [Alert(LOW, "wallets", f"disc:{t:%Y%m%d}", f"Wallet discovery: {added} new labelled casino wallets, {len(found)} watched in total")] if added else []


# ---------------------------------------------------------------- freezes
def check_freezes(cfg, state, http, t, budget=None):
    rules = cfg.get("freeze_rules", {})
    win = dt.timedelta(minutes=rules.get("batch_minutes", 15))
    min_batch = rules.get("min_batch", 3)
    big = rules.get("big_single_usd", 1_000_000)
    st = state.setdefault("freezes", {"seen": []})
    seen = set(st.get("seen", []))
    try:
        items = http.json("https://stablescan.achivx.com/v1/freezes/acts?limit=200")["items"]
    except Exception as e:
        log(f"freezes: {e}")
        return []
    first_run = not st.get("seen")
    new = [x for x in items if x["action"] in ("freeze", "seize") and f"{x['tx_hash']}:{x['subject']}" not in seen]
    for x in items:
        seen.add(f"{x['tx_hash']}:{x['subject']}")
    st["seen"] = list(seen)[-3000:]
    if first_run or not new:
        return []

    pinned, disc = load_wallets(cfg, state)
    casino = {w["address"].lower(): w["name"] for w in pinned + disc}

    def amount(x):
        usd = None
        try:
            r = http.json(f"https://stablescan.achivx.com/v1/addresses/{x['subject']}?chain={x['chain_slug']}")
            for f in r.get("freeze") or []:
                if f.get("token") == x["token"] and f.get("frozen_usd6") is not None:
                    usd = f["frozen_usd6"] / 1e6
        except Exception:
            pass
        try:  # does the frozen wallet trade with a casino wallet we watch?
            g = http.json(f"https://stablescan.achivx.com/v1/addresses/{x['subject']}/graph?chain={x['chain_slug']}")
            x["linked"] = sorted({casino[n["address"].lower()] for n in g.get("nodes") or []
                                  if n.get("hop") == 1 and (n.get("address") or "").lower() in casino})
        except Exception:
            x["linked"] = []
        return usd

    with ThreadPoolExecutor(6) as ex:
        amts = list(ex.map(amount, new[:40]))
    for x, a in zip(new, amts + [None] * len(new)):
        x["usd"] = a
    new.sort(key=lambda x: (x["chain_slug"], x["block_time"]))
    groups, cur = [], []
    for x in new:
        if cur and (x["chain_slug"] != cur[-1]["chain_slug"] or
                    parse_iso(x["block_time"]) - parse_iso(cur[0]["block_time"]) > win):
            groups.append(cur)
            cur = []
        cur.append(x)
    if cur:
        groups.append(cur)
    alerts = []
    for x in new:
        if x.get("linked"):
            alerts.append(Alert(HIGH, "freeze", f"fzl:{x['tx_hash']}:{x['subject']}",
                f"FROZEN WALLET LINKED TO A CASINO: {x['token']} freeze on {x['chain_slug']}, ${x.get('usd') or 0:,.0f} locked. "
                f"It has traded directly with {', '.join(x['linked'][:4])}. {x['subject']}"))
    for g in groups:
        total = sum(x.get("usd") or 0 for x in g)
        biggest = max((x.get("usd") or 0) for x in g)
        if len(g) >= min_batch or biggest >= big:
            lines = "; ".join(f"{x['subject']} ${x['usd'] or 0:,.0f}" for x in sorted(g, key=lambda x: -(x.get('usd') or 0))[:6])
            alerts.append(Alert(HIGH, "freeze", f"fz:{g[0]['tx_hash']}",
                f"FREEZE BATCH: {len(g)} {g[0]['token']} freezes on {g[0]['chain_slug']} at {g[0]['block_time'][:16]}Z, "
                f"about ${total:,.0f} locked. {lines} https://stablescan.achivx.com"))
        else:
            for x in g:
                alerts.append(Alert(LOW, "freeze", f"fz:{x['tx_hash']}:{x['subject']}",
                    f"Freeze {x['token']} {x['chain_slug']} {x['subject']} ${x.get('usd') or 0:,.0f}"))
    return alerts


# ---------------------------------------------------------------- sites
MAINT_RE = re.compile(r"(under maintenance|maintenance mode|scheduled maintenance|we.ll be back|"
                      r"temporarily unavailable|technical work|site is down|currently unavailable|"
                      r"en mantenimiento|wartungsarbeiten|manuten[cç][aã]o|bakımda|в разработке|техническ)", re.I)
CHALLENGE_RE = re.compile(r"(just a moment|cf-chl|attention required|checking your browser|ddos-guard|captcha|"
                          r"access denied|not available in your (country|region)|restricted (country|region)|"
                          r"geo.?block)", re.I)
SEIZED_RE = re.compile(r"(this (domain|website|site) (name )?has been seized|seized by (the )?(fbi|police|homeland|europol|law enforcement)|"
                       r"domain seized|website seized|beschlagnahmt|zabaven[aoý]|saisi par|sequestrad[oa] por|in beslag genomen)", re.I)
NOTICE_RE = re.compile(r"(withdrawals? (are |is )?(temporarily )?(paused|suspended|disabled|delayed|unavailable)|"
                       r"(we are|we're) (closing|shutting down|ceasing)|ceas(e|ing) (all )?operations|"
                       r"no longer (accept|available)|final withdrawal|account(s)? will be closed|"
                       r"security incident|unauthori[sz]ed access|we (have been|were) (hacked|attacked))", re.I)
PARKED_RE = re.compile(r"(domain (is )?for sale|buy this domain|parked free|sedo|dan\.com|afternic|"
                       r"this domain (name )?(has expired|is parked)|godaddy\.com/forsale)", re.I)


def classify_site(http, domain):
    try:
        r = http.snippet(f"https://{domain}")
    except requests.exceptions.SSLError:
        return "down", "TLS error"
    except requests.exceptions.ConnectionError as e:
        s = str(e)
        return "down", "DNS failure" if ("Name or service" in s or "NameResolution" in s or "getaddrinfo" in s) else "no connection"
    except requests.exceptions.Timeout:
        return "down", "timeout"
    except Exception as e:
        return "blocked", f"error {type(e).__name__}"
    body = getattr(r, "_snip", "")
    title = (re.search(r"<title[^>]*>(.*?)</title>", body, re.I | re.S) or [None, ""])[1].strip()[:80]
    if "maintenance" in r.url.lower():
        return "maintenance", f"redirects to {r.url[:80]}"
    if SEIZED_RE.search(body[:30000]):
        return "seized", "page shows a seizure banner"
    if PARKED_RE.search(body[:20000]):
        return "parked", "domain parked or for sale"
    if CHALLENGE_RE.search(body[:20000]) and r.status_code in (403, 429, 451, 503):
        return "blocked", f"bot or geo check {r.status_code}"
    if r.status_code >= 500:
        return "down", f"HTTP {r.status_code}"
    visible = re.sub(r"<script.*?</script>|<style.*?</style>|<[^>]+>", " ", body, flags=re.S | re.I)
    m = MAINT_RE.search(title) or (MAINT_RE.search(visible) if len(visible.split()) < 400 else None)
    if m:
        return "maintenance", f"page says: {title or m.group(0)}"
    n = NOTICE_RE.search(visible[:30000])
    if n:
        return "notice", f"page says: \"{n.group(0)}\""
    host = norm_domain(r.url)
    if host and host != norm_domain(domain) and not host.endswith("." + norm_domain(domain)) \
            and not norm_domain(domain).endswith("." + host):
        return "moved", f"now redirects to {host}"
    if r.status_code in (401, 403, 404, 410, 429, 451):
        return "blocked", f"HTTP {r.status_code}"
    return "up", f"HTTP {r.status_code}"


def licence_index(state):
    """domain -> (regulator, licence number, company), from the stored registers."""
    idx = {}
    for num, rec in (state.get("registers", {}).get("anjouan") or {}).items():
        for d in rec.get("domains", []):
            idx.setdefault(d, ("Anjouan", num, rec.get("company", "")))
    for num, rec in (state.get("registers", {}).get("curacao") or {}).items():
        for d in rec.get("domains", []):
            idx.setdefault(d, ("Curaçao", num, rec.get("company", "")))
    return idx


def check_sites(cfg, state, http, t, budget=None):
    """Priority sites every run; all register domains in rotation. A domain that
    looks bad is rechecked next run together with every domain on its licence."""
    rules = cfg.get("site_rules", {})
    st = state.setdefault("sites", {})
    idx = licence_index(state)
    priority = [norm_domain(s if isinstance(s, str) else s["domain"]) for s in cfg.get("sites", [])]
    recheck = state.get("site_recheck", [])
    pool = sorted(set(idx) - set(priority))
    batch = list(dict.fromkeys(priority + recheck +
                               rotate(pool, state.setdefault("cursors", {}), "sites", rules.get("rotation_per_run", 500))))

    def one(d):
        if budget and not budget.ok(TIMEOUT + 2):
            return d, None
        return d, classify_site(http, d)

    with ThreadPoolExecutor(rules.get("threads", 64)) as ex:
        res = dict(ex.map(one, batch))
    went_bad, came_back, suspects = [], [], set()
    for d, r in res.items():
        if r is None:
            continue
        status, why = r
        if status == "blocked":
            continue
        rec = st.get(d)
        if rec is None:  # first sighting: baseline, no alert
            st[d] = {"s": status, "n": 2, "r": "up" if status == "up" else status, "w": why, "at": iso(t)}
            continue
        rec["n"] = rec["n"] + 1 if status == rec["s"] else 1
        rec["s"], rec["w"], rec["at"] = status, why, iso(t)
        bad = status in ("maintenance", "down", "parked", "notice", "moved", "seized")
        if bad and rec["n"] == 1 and rec["r"] == "up":
            suspects.add(d)  # recheck next run before alerting
        if bad and rec["n"] >= 2 and rec["r"] == "up":
            rec["r"] = status
            went_bad.append((d, status, why))
        elif status == "up" and rec["r"] != "up" and rec["n"] >= 2:
            rec["r"] = "up"
            came_back.append(d)
    # recheck suspects and their licence siblings next run
    nxt = set(suspects)
    for d in suspects:
        if d in idx:
            lic = idx[d][1]
            nxt |= {x for x, v in idx.items() if v[1] == lic}
    state["site_recheck"] = sorted(nxt)[:400]
    alerts = []
    by_lic = {}
    for d, s, why in went_bad:
        lic = idx.get(d)
        by_lic.setdefault(lic[:2] if lic else ("none", d), []).append((d, s, why, lic))
    cluster = rules.get("cluster_min", 3)
    used = set()
    for k, items in by_lic.items():
        if k[0] != "none" and len(items) >= cluster:
            _, num, company = items[0][3]
            used |= {i[0] for i in items}
            alerts.append(Alert(HIGH, "sites", f"lic:{num}:{t:%Y%m%d}",
                f"LICENCE CLUSTER DOWN: {len(items)} sites under {k[0]} licence {num} ({company}) went down: "
                + ", ".join(f"{d} ({s})" for d, s, _, _ in items[:15]) + ". Same licence holder: check bankroll/platform."))
    rest = [x for x in went_bad if x[0] not in used]
    prio = set(priority)
    if len(rest) >= rules.get("run_cluster_min", 8):
        alerts.append(Alert(HIGH, "sites", f"cluster:{t:%Y%m%d%H}",
            f"MANY SITES DOWN AT ONCE: {len(rest)} casino sites: " + ", ".join(f"{d} ({s})" for d, s, _ in rest[:25])))
    else:
        for d, s, why in rest:
            lic = idx.get(d)
            lic_txt = f" [{lic[0]} {lic[1]}, {lic[2]}]" if lic else ""
            level = HIGH if d in prio or s in ("seized", "notice") else LOW
            alerts.append(Alert(level, "sites", f"site:{d}:{t:%Y%m%d}", f"{d} is {s}: {why}{lic_txt}"))
    for d in came_back:
        alerts.append(Alert(HIGH if d in prio else LOW, "sites", f"back:{d}:{t:%Y%m%d}", f"{d} is back up"))
    state["sites_meta"] = {"checked": sum(1 for v in res.values() if v), "known": len(st), "at": iso(t)}
    return alerts


# ---------------------------------------------------------------- registers
def fetch_anjouan(http):
    h = http.get("https://anjouangaming.com/public-register/license-register/", timeout=25).text
    m = re.search(r'<script[^>]*id="ag-licence-data"[^>]*>(.*?)</script>', h, re.S)
    if not m:
        raise ValueError("Anjouan register data block not found")
    rows = json.loads(m.group(1))
    out = {}
    for r in rows:
        num = (r.get("number") or "").strip()
        if not num:
            continue
        doms = sorted({norm_domain(x) for x in str(r.get("domains") or "").split(",") if x.strip()})
        out[num] = {"company": (r.get("company") or "").strip(), "status": (r.get("status") or "").lower(),
                    "type": r.get("type"), "issued": r.get("issued"), "expiry": r.get("expiry"), "domains": doms}
    return out


def stem(d):
    s = d.split(".")[0]
    s = re.sub(r"(casino|bet|win|play|\d+)$", "", s) or s
    return re.sub(r"^(the|my|play)", "", s)


def diff_register(name, old, new, brands, t):
    """Compare two register snapshots: licences and domains added or removed,
    status changes, and mirror brands that reappear under another company."""
    alerts = []
    brand_re = re.compile("|".join(re.escape(b.lower()) for b in brands)) if brands else None

    def known(ds):
        return [d for d in ds if brand_re and brand_re.search(d)]

    for num in sorted(set(old) - set(new)):
        o = old[num]
        lvl = HIGH if known(o["domains"]) or len(o["domains"]) >= 5 else LOW
        alerts.append(Alert(lvl, "register", f"reg:{name}:gone:{num}",
            f"{name.upper()} LICENCE GONE from register: {num} {o['company']} ({len(o['domains'])} domains: "
            f"{', '.join(o['domains'][:8])})"))
    # stems of domains held by each company, to spot mirrors under a new company
    stems_by_company = {}
    for num, o in old.items():
        for d in o["domains"]:
            stems_by_company.setdefault(stem(d), set()).add(o["company"])
    for num in sorted(set(new) - set(old)):
        n = new[num]
        mirrors = sorted({d for d in n["domains"] if any(c != n["company"] for c in stems_by_company.get(stem(d), set()))})
        if len(mirrors) >= 2:
            owners = sorted({c for d in mirrors for c in stems_by_company.get(stem(d), set()) if c != n["company"]})
            alerts.append(Alert(HIGH, "register", f"reg:{name}:mirror:{num}",
                f"{name.upper()} NEW LICENCE WITH COPIED BRANDS: {num} {n['company']} has {len(mirrors)} domains matching "
                f"brands of {', '.join(owners[:4])}: {', '.join(mirrors[:10])}"))
        else:
            lvl = HIGH if known(n["domains"]) else LOW
            alerts.append(Alert(lvl, "register", f"reg:{name}:new:{num}",
                f"{name.capitalize()} new licence {num} {n['company']} ({n.get('type') or ''}): {', '.join(n['domains'][:10])}"))
    for num in sorted(set(old) & set(new)):
        o, n = old[num], new[num]
        if o.get("status") != n.get("status"):
            alerts.append(Alert(HIGH, "register", f"reg:{name}:status:{num}:{n.get('status')}",
                f"{name.upper()} STATUS CHANGE: {num} {n['company']} {o.get('status')} -> {n.get('status')} "
                f"({', '.join(n['domains'][:8])})"))
        gone = sorted(set(o["domains"]) - set(n["domains"]))
        added = sorted(set(n["domains"]) - set(o["domains"]))
        if gone:
            lvl = HIGH if known(gone) or len(gone) >= 5 else LOW
            alerts.append(Alert(lvl, "register", f"reg:{name}:dgone:{num}:{','.join(gone)[:60]}",
                f"{name.capitalize()} licence {num} ({n['company']}) dropped {len(gone)} domains: {', '.join(gone[:10])}"))
        if added:
            alerts.append(Alert(LOW, "register", f"reg:{name}:dadd:{num}:{','.join(added)[:60]}",
                f"{name.capitalize()} licence {num} ({n['company']}) added {len(added)} domains: {', '.join(added[:10])}"))
    return alerts


CGA_RE = {
    "lic": re.compile(r"license number\s+([A-Z]+/\d{4}/\d+/\d+)"),
    "company": re.compile(r"certify that\s+(.+?),\s+a company"),
    "status": re.compile(r"License status:\s*([A-Za-z ]+?)\."),
    "app": re.compile(r"Application status:\s*([A-Za-z ]+?)\."),
}


def parse_cga(text):
    plain = re.sub(r"\s+", " ", re.sub(r"<[^>]+>", "\n", text))
    lic = CGA_RE["lic"].search(plain)
    if not lic:
        return None
    block = re.sub(r"<[^>]+>", "\n", text)
    m = re.search(r"following domains under its license:(.*?)(Copyright|$)", block, re.S)
    doms = []
    if m:
        doms = sorted({norm_domain(x) for x in m.group(1).split("\n") if re.match(r"^\s*[a-z0-9.-]+\.[a-z]{2,}\s*$", x, re.I)})
    g = lambda k: (CGA_RE[k].search(plain).group(1).strip() if CGA_RE[k].search(plain) else "")
    return {"number": lic.group(1), "company": html.unescape(g("company")), "status": g("status").lower(),
            "app": g("app").lower(), "domains": doms}


def check_registers(cfg, state, http, t, budget=None):
    rcfg = cfg.get("registers", {})
    regs = state.setdefault("registers", {})
    jobs = state.setdefault("jobs", {})
    brands = cfg.get("forum", {}).get("brands", [])
    alerts = []
    # Anjouan: one page holds the whole register
    if due(jobs, "anjouan", t, rcfg.get("anjouan_every_minutes", 360)):
        try:
            new = fetch_anjouan(http)
            old = regs.get("anjouan")
            if old and len(new) > 0.5 * len(old):
                alerts += diff_register("anjouan", old, new, brands, t)
            regs["anjouan"] = new
        except Exception as e:
            jobs.pop("anjouan", None)
            log(f"anjouan: {e}")
    # Curacao: certificate pages, slowly (the server rate-limits)
    cur = regs.setdefault("curacao", {})
    cst = state.setdefault("curacao_crawl", {"next": rcfg.get("curacao_first_id", 1), "miss": 0})
    max_id = rcfg.get("curacao_max_id", 3000)
    per_run = rcfg.get("curacao_per_run", 12)
    known_ids = sorted(int(k.split("/")[-1]) for k in cur)
    # half the slots go to new ids, half to re-checking known licences
    ids = []
    for _ in range(per_run // 2):
        ids.append(cst["next"])
        cst["next"] = cst["next"] + 1 if cst["next"] < max_id else 1
    ids += rotate(known_ids, state.setdefault("cursors", {}), "curacao_known", per_run - len(ids))
    for i in ids:
        if budget and not budget.ok(6):
            break
        try:
            r = http.get(f"https://cert.cga.cw/token?id={i}", timeout=10)
        except Exception as e:
            log(f"curacao {i}: {e}")
            continue
        if r.status_code == 429:
            log("curacao: rate limited, stopping for this run")
            break
        rec = parse_cga(r.text) if r.status_code == 200 else None
        time.sleep(rcfg.get("curacao_delay_s", 2.5))
        if not rec:
            continue
        num = rec.pop("number")
        old = cur.get(num)
        cur[num] = rec
        if old:
            alerts += diff_register("curacao", {num: old}, {num: rec}, brands, t)
        elif cst.get("seeded"):
            # a licence id we had never seen, after the first full pass: a new licence
            alerts += diff_register("curacao", {}, {num: rec}, brands, t)
    if cst["next"] == 1 and known_ids:
        cst["seeded"] = True
    return alerts


# ---------------------------------------------------------------- news
def gnews(http, query, lang, country, ceid=None):
    q = urllib.parse.quote(query + " when:2d")
    ceid = ceid or f"{country}:{lang.split('-')[0]}"
    r = http.get(f"https://news.google.com/rss/search?q={q}&hl={lang}&gl={country}&ceid={ceid}")
    if r.status_code in (429, 503):
        raise RuntimeError("rate limited")
    r.raise_for_status()
    out = []
    for m in re.finditer(r"<item>(.*?)</item>", r.text, re.S):
        it = m.group(1)

        def g(tag):
            mm = re.search(rf"<{tag}[^>]*>(.*?)</{tag}>", it, re.S)
            return html.unescape(mm.group(1)).strip() if mm else ""
        su = re.search(r'<source[^>]+url=["\']([^"\']+)', it)
        out.append({"title": g("title"), "link": g("link"), "date": g("pubDate"), "source": g("source"),
                    "source_url": su.group(1) if su else ""})
    return out


def news_jobs(ncfg):
    brands = ncfg.get("brands", [])
    harvest = ncfg.get("harvest_words", [])
    size = ncfg.get("brands_per_query", 10)
    chunks = [brands[i:i + size] for i in range(0, len(brands), size)]
    jobs = []
    for e, ed in enumerate(ncfg.get("editions", [])):
        words = ed.get("words", [])
        for q in ed.get("queries", []):
            jobs.append((e, q, "generic"))
        for w in ed.get("words", [])[:harvest and 4 or 0]:
            jobs.append((e, w, "harvest"))  # broad local searches: mostly to learn new outlets
        for c, ch in enumerate(chunks):
            q = "(" + " OR ".join(f'"{b}"' for b in ch) + ")"
            if words:
                q += " (" + " OR ".join(f'"{w}"' if " " in w else w for w in words) + ")"
            jobs.append((e, q, "brand"))
    return jobs


def check_news(cfg, state, http, t, budget=None):
    ncfg = cfg.get("news", {})
    st = state.setdefault("news", {"seen": []})
    seen = set(st.get("seen", []))
    first_run = not seen
    jobs = news_jobs(ncfg)
    batch = rotate(jobs, state.setdefault("cursors", {}), "news", ncfg.get("queries_per_run", 40))
    eds = ncfg.get("editions", [])
    exclude = [x.lower() for x in ncfg.get("exclude_sources", [])]
    hot = re.compile("|".join(re.escape(b.lower()) for b in ncfg.get("brands", []) + ncfg.get("hot_words", [])), re.I)
    stop = threading.Event()

    def run(job):
        e, q, kind = job
        if stop.is_set() or (budget and not budget.ok(TIMEOUT + 2)):
            return job, []
        ed = eds[e]
        try:
            return job, gnews(http, q, ed["lang"], ed["country"], ed.get("ceid"))
        except Exception as ex:
            if "rate limited" in str(ex):
                stop.set()
            log(f"news {ed['lang']}: {ex}")
            return job, []

    with ThreadPoolExecutor(ncfg.get("threads", 4)) as ex:
        results = list(ex.map(run, batch))
    alerts = []
    learned = state.setdefault("learned_outlets", {})
    for (e, q, kind), items in results:
        ed = eds[e]
        for it in items:
            dom = norm_domain(it.get("source_url") or "")
            if dom and "." in dom and dom not in learned and len(learned) < ncfg.get("learn_max", 8000):
                learned[dom] = ed["country"]
            k = hashlib.sha1(re.sub(r"\W+", "", it["title"].lower()).encode()).hexdigest()[:16]
            if k in seen:
                continue
            seen.add(k)
            if first_run:
                continue
            if any(x in (it["source"] or "").lower() for x in exclude):
                continue
            try:
                if t - parsedate_to_datetime(it["date"]) > dt.timedelta(hours=ncfg.get("max_age_hours", 36)):
                    continue
            except Exception:
                pass
            if kind == "harvest" and not hot.search(it["title"]):
                continue
            level = HIGH if kind == "brand" or hot.search(it["title"]) else LOW
            alerts.append(Alert(level, "news", f"n:{k}", f"[{ed['lang']}] {it['title']} ({it['date'][5:16]}) {it['link']}"))
    st["seen"] = list(seen)[-8000:]
    return alerts


# ---------------------------------------------------------------- forum
TOPIC_RE = re.compile(r'<span id="msg_\d+"><a href="[^"]*topic=(\d+)\.0">([^<]+)</a>')


def check_forum(cfg, state, http, t, budget=None):
    fcfg = cfg.get("forum", {})
    st = state.setdefault("forum", {"seen": [], "hits": {}})
    seen = set(st.get("seen", []))
    first_run = not seen
    brands = [b.lower() for b in fcfg.get("brands", [])]
    brand_res = [(b, re.compile(r"(?<![a-z0-9])" + re.escape(b) + r"(?![a-z0-9])")) for b in brands]
    words = re.compile("|".join(fcfg.get("words", ["withdraw", "scam", "hack", "frozen", "rigged"])), re.I)
    alerts = []
    for board in fcfg.get("boards", [83]):
        bid, pages = (board, 1) if isinstance(board, int) else (board["id"], board.get("pages", 1))
        for p in range(pages):
            try:
                h = http.get(f"https://bitcointalk.org/index.php?board={bid}.{p * 40}", timeout=12).text
            except Exception as e:
                log(f"forum {bid}: {e}")
                continue
            time.sleep(1)
            for tid, title in TOPIC_RE.findall(h):
                title = html.unescape(title).strip()
                if tid in seen:
                    continue
                seen.add(tid)
                if first_run:
                    continue
                tl = title.lower()
                brand = next((b for b, rx in brand_res if rx.search(tl)), None)
                scam_board = bid in fcfg.get("scam_boards", [83])
                if not brand and not (scam_board and words.search(title)):
                    continue
                url = f"https://bitcointalk.org/index.php?topic={tid}.0"
                if brand:
                    hits = [x for x in st["hits"].get(brand, []) if t - parse_iso(x) < dt.timedelta(days=7)]
                    if scam_board:
                        hits.append(iso(t))
                    st["hits"][brand] = hits
                    many = len(hits) >= fcfg.get("repeat_threshold", 2)
                    level = HIGH if (scam_board and many) or (scam_board and words.search(title) and fcfg.get("brand_scam_is_high", True)) else LOW
                    extra = f" ({len(hits)} scam threads on {brand} this week)" if many else ""
                    alerts.append(Alert(level, "forum", f"bt:{tid}", f"BitcoinTalk: {title}{extra} {url}"))
                else:
                    alerts.append(Alert(LOW, "forum", f"bt:{tid}", f"BitcoinTalk: {title} {url}"))
    st["seen"] = list(seen)[-6000:]
    return alerts


# ---------------------------------------------------------------- pages
def check_pages(cfg, state, http, t, budget=None):
    """Regulator and enforcement pages: alert on new links."""
    pcfg = cfg.get("pages", {})
    if not due(state.setdefault("jobs", {}), "pages", t, pcfg.get("every_minutes", 180)):
        return []
    st = state.setdefault("pages", {})
    alerts = []

    def one(p):
        try:
            return p, http.get(p["url"], timeout=15).text
        except Exception as e:
            log(f"page {p['name']}: {e}")
            return p, None

    with ThreadPoolExecutor(6) as ex:
        results = list(ex.map(one, pcfg.get("list", [])))
    for p, h in results:
        if not h:
            continue
        rx = re.compile(p.get("link_pattern", "."), re.I)
        links = []
        for href, text in re.findall(r'<a[^>]+href="([^"#]+)"[^>]*>(.*?)</a>', h, re.S | re.I):
            text = re.sub(r"<[^>]+>|\s+", " ", html.unescape(text)).strip()
            full = urllib.parse.urljoin(p["url"], href)
            if rx.search(full) or rx.search(text):
                links.append((full, text[:140]))
        old = set(st.get(p["name"], []))
        cur = {l for l, _ in links}
        if old:
            for l, txt in links:
                if l not in old:
                    alerts.append(Alert(HIGH if p.get("high") else LOW, "pages", f"pg:{l}",
                        f"{p['name']}: new item: {txt or l} {l}"))
                    old.add(l)
        st[p["name"]] = sorted(old | cur)[-1500:]
    return alerts


# ---------------------------------------------------------------- chain watcher
RPC = {
    "eth": "https://ethereum-rpc.publicnode.com",
    "polygon": "https://polygon-bor-rpc.publicnode.com",
    "bsc": "https://bsc-rpc.publicnode.com",
    "arbitrum": "https://arbitrum-one-rpc.publicnode.com",
    "base": "https://base-rpc.publicnode.com",
    "optimism": "https://optimism-rpc.publicnode.com",
    "etherlink": "https://node.mainnet.etherlink.com",
}
TOPIC = {
    "Transfer": "0xddf252ad1be2c89b69c2b068fc378daa952ba7f163c4a11628f55a4df523b3ef",
    "OwnershipTransferred": "0x8be0079c531659141344cd1fd0a4f28419497f9722a3daafe3b4186f6b6457e0",
    "RoleGranted": "0x2f8788117e7eff1d82e926ec794901d17c78024a50270940304540a733656f0d",
    "RoleRevoked": "0xf6391f5c32d9c69d2a47ea670b442974b53935d1edc7fd64eb21e047a839171b",
    "Upgraded": "0xbc7cd75a20ee27fd9adebab32041f755214dbc6bffa90cc0225b39da2e5c2d3b",
    "AdminChanged": "0x7e644d79422f17c01e4894b5f4f588d331ebfa28653d42ae832dc59e38c9798f",
    "Paused": "0x62e78cea01bee320cd4e420270b5ea74000d11b0c9f74754ebdbfc544b05a258",
    "Unpaused": "0x5db9ee0a495bf2e6ff9c91a7834c1ba4fdd244a5e8aa4e537bd38aeae4b073aa",
    "BeaconUpgraded": "0x1cf3b03a6cf19fa2baba4df148e9dcabedea7f8a5c07840e207e5c089be95d3e",
}
ADMIN_TOPICS = {v: k for k, v in TOPIC.items() if k != "Transfer"}
# major tokens per chain: address -> (symbol, decimals, usd per unit or None = use native price)
MAJOR = {
    "eth": {"0xdac17f958d2ee523a2206206994597c13d831ec7": ("USDT", 6, 1), "0xa0b86991c6218b36c1d19d4a2e9eb0ce3606eb48": ("USDC", 6, 1),
            "0x6b175474e89094c44da98b954eedeac495271d0f": ("DAI", 18, 1), "0xc02aaa39b223fe8d0a0e5c4f27ead9083c756cc2": ("WETH", 18, None)},
    "polygon": {"0xc2132d05d31c914a87c6611c10748aeb04b58e8f": ("USDT", 6, 1), "0x3c499c542cef5e3811e1192ce70d8cc03d5c3359": ("USDC", 6, 1),
                "0x2791bca1f2de4661ed88a30c99a7a9449aa84174": ("USDC.e", 6, 1), "0x8f3cf7ad23cd3cadbd9735aff958023239c6a063": ("DAI", 18, 1),
                "0x7ceb23fd6bc0add59e62ac25578270cff1b9f619": ("WETH", 18, None)},
    "bsc": {"0x55d398326f99059ff775485246999027b3197955": ("USDT", 18, 1), "0x8ac76a51cc950d9822d68b83fe1ad97b32cd580d": ("USDC", 18, 1)},
    "arbitrum": {"0xfd086bc7cd5c481dcc9c85ebe478a1c0b69fcbb9": ("USDT", 6, 1), "0xaf88d065e77c8cc2239327c5edb3a432268e5831": ("USDC", 6, 1),
                 "0x82af49447d8a07e3bd95bd0d56f35241523fbab1": ("WETH", 18, None)},
    "base": {"0x833589fcd6edb6e08f4c7c32d4f71b54bda02913": ("USDC", 6, 1), "0x4200000000000000000000000000000000000006": ("WETH", 18, None)},
    "optimism": {"0x0b2c639c533813f4aa9d7837caf62653d097ff85": ("USDC", 6, 1), "0x94b008aa00579c1307b0ef2c499ad98a8ce58e58": ("USDT", 6, 1),
                 "0x4200000000000000000000000000000000000006": ("WETH", 18, None)},
    "etherlink": {"0x796ea11fa2dd751ed01b53c372ffdb4aaa8f00f9": ("USDC", 6, 1), "0x2c03058c8afc06713be23e58d2febc8337dbfe6a": ("USDT", 6, 1),
                  "0x6bde51212203ae5d592cc5180da2abbd41c922de": ("USDSM", 18, 1)},
}
EXPLORER = {"eth": "https://etherscan.io", "polygon": "https://polygonscan.com", "bsc": "https://bscscan.com",
            "arbitrum": "https://arbiscan.io", "base": "https://basescan.org", "optimism": "https://optimistic.etherscan.io",
            "etherlink": "https://explorer.etherlink.com"}


def rpc(http, chain, method, params):
    r = http.post(RPC[chain], json={"jsonrpc": "2.0", "id": 1, "method": method, "params": params}, timeout=12)
    j = r.json()
    if "error" in j:
        raise RuntimeError(f"{chain} {method}: {j['error'].get('message', j['error'])}")
    return j["result"]


def pad(a):
    return "0x" + a.lower().replace("0x", "").rjust(64, "0")


def unpad(t):
    return "0x" + t[-40:]


def eth_price(http):
    try:
        d = http.json("https://api.geckoterminal.com/api/v2/simple/networks/eth/token_price/0xc02aaa39b223fe8d0a0e5c4f27ead9083c756cc2")
        return float(list(d["data"]["attributes"]["token_prices"].values())[0])
    except Exception:
        return 0.0


def watched_evm(cfg, state, base_dir="."):
    """chain -> {address: name} for every EVM wallet we watch (pinned, csv, discovered)."""
    pinned, disc = load_wallets(cfg, state, base_dir)
    out = {}
    for w in pinned + disc:
        if w["chain"] in RPC:
            out.setdefault(w["chain"], {})[w["address"].lower()] = (w["name"], w.get("kind", "hot"), float(w.get("min_usd") or 0))
    return out


def scan_logs(http, chain, frm, to, address, topics, step=2000):
    logs = []
    b = frm
    while b <= to:
        e = min(to, b + step - 1)
        logs += rpc(http, chain, "eth_getLogs", [{"fromBlock": hex(b), "toBlock": hex(e), "address": address, "topics": topics}])
        b = e + 1
    return logs


def deposit_drops(cfg, state, watched, t):
    """Once a day: a hot wallet whose deposits yesterday fell below drop_share of its 7-day average."""
    ccfg = cfg.get("chains", {})
    share, min_avg = ccfg.get("deposit_drop_share", 0.25), ccfg.get("deposit_min_avg_usd", 50000)
    flows = state.setdefault("flows", {})
    out = []
    y = (t - dt.timedelta(days=1)).strftime("%Y-%m-%d")
    prior = [(t - dt.timedelta(days=d)).strftime("%Y-%m-%d") for d in range(2, 9)]
    since = state.setdefault("flow_since", {})
    checked = state.setdefault("flow_checked", {})
    for key, rec in flows.items():
        since.setdefault(key, min(rec, default=f"{t:%Y-%m-%d}"))
        for d in [d for d in rec if d < prior[-1]]:
            del rec[d]  # keep 8 days
        if checked.get(key) == y or since[key] > prior[-1]:
            continue  # already checked today, or less than 8 days of history
        state["flow_checked"][key] = y
        avg = sum(rec.get(d, 0) for d in prior) / 7
        got = rec.get(y, 0)
        if avg >= min_avg and got < avg * share:
            chain, addr = key.split(":", 1)
            name = watched.get(chain, {}).get(addr, ("?",))[0]
            out.append(Alert(HIGH, "chain", f"flow:{key}:{y}",
                f"DEPOSITS COLLAPSED: {name} received ${got:,.0f} on {y}, down {1 - got / avg:.0%} from its 7-day average "
                f"of ${avg:,.0f} a day ({chain}). {EXPLORER.get(chain, '')}/address/{addr}"))
    return out


def check_chains(cfg, state, http, t, budget=None, base_dir="."):
    """Per chain, new blocks since last run:
    - big stablecoin/WETH outflows from any watched wallet; HIGH when the receiver
      is a fresh address or a known mixer/bridge (classic hot wallet hack shape)
    - admin events on watched contracts (owner/role change, upgrade, pause)
    - a watched contract sending out most of a token balance (Betfin LP drain shape)"""
    ccfg = cfg.get("chains", {})
    st = state.setdefault("chainwatch", {})
    alerts = []
    watched = watched_evm(cfg, state, base_dir)
    contracts = {}
    for c in cfg.get("contracts", []):
        contracts.setdefault(c["chain"], []).append(c)
    mixers = {k.lower(): v for k, v in (ccfg.get("mixers") or {}).items()}
    min_usd = ccfg.get("outflow_min_usd", 250000)
    fresh_max = ccfg.get("fresh_max_txs", 3)
    ethp = None
    chains = [c for c in RPC if c in watched or c in contracts]

    def one(chain):
        nonlocal ethp
        out = []
        try:
            head = int(rpc(http, chain, "eth_blockNumber", []), 16)
        except Exception as e:
            log(f"chain {chain}: {e}")
            return out
        cur = st.get(chain)
        if cur is None:
            st[chain] = head
            return out
        frm, to = cur + 1, min(head, cur + ccfg.get("max_blocks_per_run", 20000))
        if frm > to:
            return out
        try:
            # 1. outflows from watched wallets, major tokens, wallets OR-ed in chunks
            addrs = list(watched.get(chain, {}))
            toks = list(MAJOR.get(chain, {}))
            for i in range(0, len(addrs), 100):
                if budget and not budget.ok(4):
                    break
                part = addrs[i:i + 100]
                for l in scan_logs(http, chain, frm, to, toks, [TOPIC["Transfer"], [pad(a) for a in part]]):
                    sym, dec, px = MAJOR[chain][l["address"].lower()]
                    if px is None:
                        if ethp is None:
                            ethp = eth_price(http)
                        px = ethp
                    usd = int(l["data"], 16) / 10 ** dec * px
                    src, dst = unpad(l["topics"][1]), unpad(l["topics"][2])
                    name, kind, wmin = watched[chain].get(src, ("?", "hot", 0))
                    if usd < (wmin if kind == "parked" and wmin else min_usd):
                        continue
                    tag, level = "", LOW
                    if dst in mixers:
                        tag, level = f" to {mixers[dst]}", HIGH
                    else:
                        try:
                            n = int(rpc(http, chain, "eth_getTransactionCount", [dst, "latest"]), 16)
                            code = rpc(http, chain, "eth_getCode", [dst, "latest"])
                            if n <= fresh_max and code in ("0x", "0x0"):
                                tag, level = f" to a FRESH address ({n} txs)", HIGH
                        except Exception:
                            pass
                    if kind == "parked":
                        level = HIGH
                    elif not tag and usd >= ccfg.get("big_payout_usd", 2_000_000):
                        tag, level = " (possible big win payout or treasury move)", HIGH
                    out.append(Alert(level, "chain", f"out:{l['transactionHash']}:{l['logIndex']}",
                        f"OUTFLOW: {name} sent ${usd:,.0f} {sym}{tag} on {chain}. "
                        f"{EXPLORER[chain]}/tx/{l['transactionHash']}"))
            # 1b. deposits into hot wallets: daily USD tally, used to spot a collapse in deposits (Betfin shape)
            hot = [a for a in addrs if watched[chain][a][1] != "parked"]
            flows = state.setdefault("flows", {})
            day = f"{t:%Y-%m-%d}"
            for i in range(0, len(hot), 100):
                if budget and not budget.ok(4):
                    break
                part = hot[i:i + 100]
                for l in scan_logs(http, chain, frm, to, toks, [TOPIC["Transfer"], None, [pad(a) for a in part]]):
                    if len(l.get("topics", [])) < 3:
                        continue
                    dst = unpad(l["topics"][2])
                    if dst not in watched[chain]:
                        continue
                    sym, dec, px = MAJOR[chain][l["address"].lower()]
                    if px is None:
                        if ethp is None:
                            ethp = eth_price(http)
                        px = ethp
                    rec = flows.setdefault(f"{chain}:{dst}", {})
                    rec[day] = rec.get(day, 0) + int(l["data"], 16) / 10 ** dec * px
            # 2 + 3. watched contracts
            for c in contracts.get(chain, []):
                if budget and not budget.ok(4):
                    break
                a = c["address"].lower()
                for l in scan_logs(http, chain, frm, to, a, [list(ADMIN_TOPICS)]):
                    ev = ADMIN_TOPICS.get(l["topics"][0], "admin event")
                    out.append(Alert(HIGH, "chain", f"adm:{l['transactionHash']}:{l['logIndex']}",
                        f"CONTRACT {ev.upper()}: {c['name']} ({chain} {a[:10]}…) {EXPLORER[chain]}/tx/{l['transactionHash']}"))
                toks = list({x.lower() for x in c.get("tokens", [])} | set(MAJOR.get(chain, {})))
                for l in scan_logs(http, chain, frm, to, toks, [TOPIC["Transfer"], pad(a)]):
                    amt = int(l["data"], 16)
                    try:
                        bal = int(rpc(http, chain, "eth_call", [{"to": l["address"], "data": "0x70a08231" + pad(a)[2:]}, "latest"]), 16)
                    except Exception:
                        continue
                    share = amt / (amt + bal) if amt + bal else 0
                    if share >= c.get("drain_share", 0.5) and amt > 0:
                        sym = MAJOR.get(chain, {}).get(l["address"].lower(), (l["address"][:10],))[0]
                        out.append(Alert(HIGH, "chain", f"drain:{l['transactionHash']}:{l['logIndex']}",
                            f"CONTRACT DRAINED: {c['name']} sent {share:.0%} of its {sym} balance to {unpad(l['topics'][2])} "
                            f"on {chain}. {EXPLORER[chain]}/tx/{l['transactionHash']}"))
            st[chain] = to
        except Exception as e:
            log(f"chain {chain}: {e}")  # cursor not moved: retried next run
        return out

    with ThreadPoolExecutor(len(chains) or 1) as ex:
        for got in ex.map(one, chains):
            alerts += got
    alerts += deposit_drops(cfg, state, watched, t)
    return alerts


# ---------------------------------------------------------------- on-chain messages
def decode_message(raw):
    """Readable text in a transaction's input (how hack negotiations happen on chain)."""
    if not raw or len(raw) < 26:
        return None
    try:
        b = bytes.fromhex(raw[2:] if raw.startswith("0x") else raw)
    except ValueError:
        return None
    try:
        s = b.decode("utf-8")
    except UnicodeDecodeError:
        return None
    printable = sum(ch.isprintable() or ch in "\n\r\t" for ch in s)
    if printable / max(len(s), 1) < 0.95 or " " not in s or len(s.strip()) < 12:
        return None
    return re.sub(r"\s+", " ", s).strip()


def check_messages(cfg, state, http, t, budget=None, base_dir="."):
    """Readable messages sent to or from watched wallets (pinned + rotation)."""
    st = state.setdefault("messages", {"seen": []})
    seen = set(st["seen"])
    pinned, disc = load_wallets(cfg, state, base_dir)
    batch = [w for w in pinned if w["chain"] in BLOCKSCOUT] + \
        rotate([w for w in disc if w["chain"] in BLOCKSCOUT], state.setdefault("cursors", {}), "messages", cfg.get("messages_per_run", 40))
    first = not seen
    alerts = []

    def one(w):
        if budget and not budget.ok(3):
            return w, []
        try:
            return w, http.json(f"{BLOCKSCOUT[w['chain']]}/api/v2/addresses/{w['address']}/transactions").get("items") or []
        except Exception as e:
            log(f"messages {w['name']}: {e}")
            return w, []

    with ThreadPoolExecutor(8) as ex:
        for w, items in ex.map(one, batch):
            for x in items[:50]:
                h = x.get("hash")
                if not h or h in seen:
                    continue
                seen.add(h)
                msg = decode_message(x.get("raw_input") or "")
                if not msg or first:
                    continue
                frm = ((x.get("from") or {}).get("hash") or "")
                direction = "from" if frm.lower() == w["address"].lower() else "to"
                alerts.append(Alert(HIGH if w.get("kind") == "parked" else LOW, "message", f"msg:{h}",
                    f"ON-CHAIN MESSAGE {direction} {w['name']} ({w['chain']}): \"{msg[:300]}\" "
                    f"{BLOCKSCOUT[w['chain']]}/tx/{h}"))
    st["seen"] = list(seen)[-20000:]
    return alerts


# ---------------------------------------------------------------- hacks database + freeze proposals
def check_hacks(cfg, state, http, t, budget=None):
    """New entries in DefiLlama's hack database. Gambling targets are HIGH."""
    hcfg = cfg.get("hacks", {})
    if not due(state.setdefault("jobs", {}), "hacks", t, hcfg.get("every_minutes", 60)):
        return []
    st = state.setdefault("hacks", {"seen": []})
    try:
        rows = http.json("https://api.llama.fi/hacks", timeout=20)
    except Exception as e:
        log(f"hacks: {e}")
        return []
    seen = set(st["seen"])
    first = not seen
    hot = re.compile(hcfg.get("high_pattern", r"casino|gambl|bet|dice|lotter|bankroll|sportsbook|poker|stake|game"), re.I)
    alerts = []
    for r in rows:
        k = f"{r.get('name')}:{r.get('date')}"
        if k in seen:
            continue
        seen.add(k)
        if first:
            continue
        text = " ".join(str(r.get(x) or "") for x in ("name", "targetType", "description", "classification"))
        level = HIGH if hot.search(text) or (r.get("amount") or 0) >= hcfg.get("high_usd", 20_000_000) else LOW
        day = dt.datetime.fromtimestamp(int(r.get("date") or 0), dt.timezone.utc).strftime("%Y-%m-%d")
        alerts.append(Alert(level, "hacks", f"hk:{k}",
            f"HACK LOGGED: {r.get('name')} ({r.get('targetType')}) ${float(r.get('amount') or 0):,.0f} on "
            f"{', '.join(r.get('chain') or [])}, {day}. {r.get('technique') or r.get('classification') or ''} {r.get('source') or ''}".strip()))
    st["seen"] = list(seen)
    return alerts


def check_freeze_proposals(cfg, state, http, t, budget=None):
    """Tether's multisig proposes a freeze or seizure before it executes."""
    st = state.setdefault("proposals", {"seen": []})
    seen = set(st["seen"])
    first = not seen
    alerts = []
    for chain in cfg.get("freeze_rules", {}).get("proposal_chains", ["tron", "ethereum"]):
        try:
            items = http.json(f"https://stablescan.achivx.com/v1/freezes/proposals?chain={chain}&status=pending&limit=50").get("items") or []
        except Exception as e:
            log(f"proposals {chain}: {e}")
            continue
        for p in items:
            k = f"{chain}:{p.get('submitted_at')}:{p.get('action')}:{p.get('selector')}"
            if k in seen:
                continue
            seen.add(k)
            if first:
                continue
            act = p.get("action") or p.get("selector")
            level = HIGH if act == "seize" else LOW
            alerts.append(Alert(level, "freeze", f"prop:{k}",
                f"PENDING {p.get('token')} {str(act).upper()} on {chain}: multisig proposal submitted {p.get('submitted_at')}, "
                f"{p.get('confirmations')}/{p.get('required')} signatures (address hidden until it executes)."))
    st["seen"] = list(seen)[-3000:]
    return alerts


# ---------------------------------------------------------------- outlets (RSS)
FEED_LINK_RE = re.compile(r'<link[^>]+type=["\']application/(?:rss|atom)\+xml["\'][^>]*>', re.I)


def load_outlets(cfg, base_dir=".", state=None):
    ocfg = cfg.get("outlets", {})
    files = ocfg.get("files") or [ocfg.get("file", "outlets.txt")]
    out, seen = [], set()
    for fn in files:
        path = os.path.join(base_dir, fn)
        if not os.path.exists(path):
            continue
        for line in open(path, encoding="utf-8"):
            line = line.split("#", 1)[0].strip() if not line.lstrip().startswith("http") else line.strip()
            if not line or line.startswith("#"):
                continue
            parts = line.split()
            if parts[0] not in seen:
                seen.add(parts[0])
                out.append({"src": parts[0], "tags": parts[1:]})
    known = {norm_domain(o["src"]) for o in out}
    for dom, cc in sorted((state or {}).get("learned_outlets", {}).items()):
        if dom not in known:
            out.append({"src": dom, "tags": [f"cc:{cc}", "learned"]})
    return out


def discover_feed(http, src):
    if src.startswith("http") and re.search(r"(rss|feed|atom|\.xml)", src, re.I):
        return src
    home = src if src.startswith("http") else f"https://{src}"
    try:
        r = http.snippet(home, limit=200000)
        for tag in FEED_LINK_RE.findall(getattr(r, "_snip", "")):
            m = re.search(r'href=["\']([^"\']+)["\']', tag)
            if m:
                return urllib.parse.urljoin(r.url, html.unescape(m.group(1)))
    except Exception:
        pass
    for p in ("/feed", "/rss", "/feed/", "/rss.xml", "/feed.xml", "/index.xml", "/atom.xml"):
        try:
            r = http.snippet(home.rstrip("/") + p, limit=3000)
            s = getattr(r, "_snip", "")
            if r.status_code == 200 and ("<rss" in s or "<feed" in s or "<rdf" in s):
                return r.url
        except Exception:
            continue
    return None


def parse_feed(text):
    items = []
    for m in re.finditer(r"<(item|entry)\b.*?</\1>", text, re.S | re.I):
        it = m.group(0)

        def g(tag):
            mm = re.search(rf"<{tag}\b[^>]*>(.*?)</{tag}>", it, re.S | re.I)
            v = mm.group(1) if mm else ""
            v = re.sub(r"<!\[CDATA\[(.*?)\]\]>", r"\1", v, flags=re.S)
            return html.unescape(re.sub(r"<[^>]+>", " ", v)).strip()
        link = g("link")
        if not link:
            mm = re.search(r'<link[^>]+href=["\']([^"\']+)', it)
            link = mm.group(1) if mm else ""
        items.append({"title": re.sub(r"\s+", " ", g("title")), "link": link.strip(),
                      "date": g("pubDate") or g("updated") or g("published") or g("dc:date"),
                      "summary": re.sub(r"\s+", " ", g("description") or g("summary"))[:400]})
    return items


def outlet_terms(cfg):
    brands = {b.lower() for b in cfg.get("news", {}).get("brands", []) + cfg.get("forum", {}).get("brands", [])
              if len(b) >= 4}
    words = set(cfg.get("outlets", {}).get("trigger_words", []))
    for ed in cfg.get("news", {}).get("editions", []):
        words |= {w.lower() for w in ed.get("words", [])}
    brand_re = re.compile(r"(?<![\w.])(" + "|".join(sorted((re.escape(b) for b in brands), key=len, reverse=True)) + r")(?![\w])", re.I)
    word_re = re.compile("|".join(sorted((re.escape(w) for w in words if w), key=len, reverse=True)), re.I)
    topic_re = re.compile(cfg.get("outlets", {}).get("topic_pattern",
        r"casino|gambl|betting|sportsbook|bookmaker|bankroll|igaming|prediction market|sweepstakes|kasino|kasyno|casin[oò]|apuesta|aposta|bahis|cassino|kaszin|hazard|พนัน|カジノ|카지노|赌|賭|казино|ставк"), re.I)
    return brand_re, word_re, topic_re


def check_outlets(cfg, state, http, t, budget=None, base_dir="."):
    """Hundreds of outlets' own RSS feeds, read in rotation. Alerts when a casino
    brand appears with a trigger word; security/crypto outlets also alert on any
    gambling story with a trigger word."""
    ocfg = cfg.get("outlets", {})
    outlets = load_outlets(cfg, base_dir, state)
    if not outlets:
        return []
    st = state.setdefault("outlets", {"feeds": {}, "seen": []})
    feeds = st["feeds"]
    seen = set(st["seen"])
    first = not seen
    brand_re, word_re, topic_re = outlet_terms(cfg)
    cur = state.setdefault("cursors", {})
    # discover feeds for outlets not yet resolved (or retry failures weekly)
    todo = [o for o in outlets if o["src"] not in feeds or
            (feeds[o["src"]] is None and t - parse_iso(st.get("disc_at", {}).get(o["src"], "2000-01-01T00:00:00Z")) > dt.timedelta(days=7))]
    disc_batch = todo[:ocfg.get("discover_per_run", 30)]

    def disc(o):
        if budget and not budget.ok(TIMEOUT + 2):
            return o, "skip"
        return o, discover_feed(http, o["src"])

    with ThreadPoolExecutor(16) as ex:
        for o, f in ex.map(disc, disc_batch):
            if f == "skip":
                continue
            feeds[o["src"]] = f
            st.setdefault("disc_at", {})[o["src"]] = iso(t)
    live = [o for o in outlets if feeds.get(o["src"])]
    batch = rotate(live, cur, "outlets", ocfg.get("feeds_per_run", 150))

    def fetch(o):
        if budget and not budget.ok(TIMEOUT + 2):
            return o, []
        try:
            r = http.snippet(feeds[o["src"]], limit=400000)
            return o, parse_feed(getattr(r, "_snip", ""))
        except Exception as e:
            return o, []

    alerts = []
    with ThreadPoolExecutor(ocfg.get("threads", 32)) as ex:
        for o, items in ex.map(fetch, batch):
            special = any(x in o["tags"] for x in ("security", "crypto", "igaming"))
            for it in items[:40]:
                key = hashlib.sha1((it["link"] or it["title"]).encode()).hexdigest()[:16]
                if key in seen:
                    continue
                seen.add(key)
                if first:
                    continue
                try:
                    if it["date"] and t - parsedate_to_datetime(it["date"]) > dt.timedelta(hours=ocfg.get("max_age_hours", 48)):
                        continue
                except Exception:
                    pass
                text = f"{it['title']} {it['summary']}"
                b = brand_re.search(text)
                w = word_re.search(text)
                if b and w:
                    level = HIGH
                elif special and topic_re.search(text) and w:
                    level = HIGH if "security" in o["tags"] else LOW
                elif b:
                    level = HIGH if any(x in o["tags"] for x in ("court", "regulator")) else LOW
                else:
                    continue
                where = next((x for x in o["tags"] if x.startswith("cc:")), "")
                alerts.append(Alert(level, "outlets", f"o:{key}",
                    f"[{o['src']}{' ' + where[3:] if where else ''}] {it['title'][:200]} {it['link']}"))
    st["seen"] = list(seen)[-30000:]
    state["outlets_meta"] = {"outlets": len(outlets), "feeds": len(live)}
    return alerts


# ---------------------------------------------------------------- telegram channels
TG_MSG_RE = re.compile(r'data-post="([^"]+)".*?<div class="tgme_widget_message_text[^"]*"[^>]*>(.*?)</div>', re.S)


def check_telegram(cfg, state, http, t, budget=None):
    """Public Telegram channels (t.me/s/<name> web preview): casino announcement
    channels and hack/security channels."""
    tcfg = cfg.get("telegram_channels", {})
    chans = tcfg.get("list", [])
    if not chans:
        return []
    st = state.setdefault("tg", {"seen": []})
    seen = set(st["seen"])
    first = not seen
    brand_re, word_re, topic_re = outlet_terms(cfg)
    batch = rotate(chans, state.setdefault("cursors", {}), "tg", tcfg.get("per_run", 40))

    def one(c):
        name = c if isinstance(c, str) else c["name"]
        if budget and not budget.ok(TIMEOUT + 2):
            return c, ""
        try:
            return c, http.get(f"https://t.me/s/{name}").text
        except Exception as e:
            log(f"telegram: {e}")
            return c, ""

    alerts = []
    with ThreadPoolExecutor(8) as ex:
        for c, h in ex.map(one, batch):
            kind = "" if isinstance(c, str) else c.get("kind", "")
            for post, body in TG_MSG_RE.findall(h):
                if post in seen:
                    continue
                seen.add(post)
                if first:
                    continue
                text = re.sub(r"\s+", " ", html.unescape(re.sub(r"<[^>]+>", " ", body))).strip()
                b, w = brand_re.search(text), word_re.search(text)
                if kind == "casino" and (w or MAINT_RE.search(text) or NOTICE_RE.search(text)):
                    level = HIGH
                elif b and w:
                    level = HIGH
                elif kind == "security" and topic_re.search(text):
                    level = HIGH
                elif b:
                    level = LOW
                else:
                    continue
                marker = "casino channel " if kind == "casino" and level == HIGH else ""
                alerts.append(Alert(level, "telegram", f"tg:{post}", f"[{marker}t.me/{post}] {text[:280]}"))
    st["seen"] = list(seen)[-20000:]
    return alerts


# ---------------------------------------------------------------- health
def record_health(state, name, ok, t):
    h = state.setdefault("health", {})
    rec = h.setdefault(name, {})
    if ok:
        rec["ok"] = iso(t)
    else:
        rec["fail"] = iso(t)


def health_lines(state, t):
    out = []
    for name, rec in sorted(state.get("health", {}).items()):
        ok = rec.get("ok")
        if not ok or t - parse_iso(ok) > dt.timedelta(hours=6):
            out.append(f"{name}: no successful run since {ok or 'start'}")
    return out


# ---------------------------------------------------------------- delivery
ORDER = ["chain", "message", "wallet", "sites", "freeze", "hacks", "token", "telegram", "register", "outlets", "news", "forum", "pages", "wallets"]
URGENT = "URGENT"
STRONG_EN = (r"hack|exploit|drain|stolen|steal|breach|attacker|arrest|raid|charged|indicted|detain|seiz|frozen|freez|"
             r"insolven|bankrupt|exit scam|rug ?pull|shut(s|ting)? down|withdrawals? (paused|suspended|halted|frozen)")


def is_urgent(cfg, a):
    """The one place that decides what gets a 🚨. Rules are listed in the README."""
    k, txt = a.key, a.text
    if a.level == URGENT:
        return True
    if k.startswith(("drain:", "adm:", "lic:", "cluster:", "fzl:", "tok:", "flow:")):
        return True
    if k.startswith("w:"):
        return True  # parked money moved, or hot wallet / bankroll drained
    if k.startswith("out:"):
        if "possible big win" in txt:
            return False  # casino paying a winner is news, not an emergency
        mixers = [m for m in (cfg.get("chains", {}).get("mixers") or {}).values() if m]
        return "FRESH" in txt or "PARKED" in txt or any(m in txt for m in mixers)
    if k.startswith("msg:"):
        return a.level == HIGH  # message to or from a parked/attacker wallet
    if k.startswith("site:"):
        return " is seized:" in txt or (a.level == HIGH and re.search(r" is (down|maintenance|notice|parked):", txt) is not None)
    if k.startswith("hk:"):
        return a.level == HIGH and re.search(cfg.get("hacks", {}).get("high_pattern",
            r"casino|gambl|bet|dice|lotter|bankroll|sportsbook|poker|stake"), txt, re.I) is not None
    if k.startswith("reg:") and (":gone:" in k or ":status:" in k):
        return a.level == HIGH
    if k.startswith("bt:"):
        return "scam threads on" in txt
    if k.startswith("tg:"):
        return "[casino channel " in txt
    if k.startswith(("n:", "o:")):
        brand_re, word_re, _ = outlet_terms(cfg)
        title = URL_RE.sub("", txt)
        local = [w for ed in cfg.get("news", {}).get("editions", []) for w in ed.get("words", [])
                 if not re.match(r"^(fined|fine|fines|banned|ban|lawsuit|sued|blocked|boete|multa|multas|förbud|illegal|illégal|ilegal|illegale|pokuta|pokutu|amende|geldstrafe|bußgeld|bøde|bot|sakko|grzywna|kara|ammenda|sanzione|sanción|sanktion|vite|prohibido|verbot|zakaz|zákaz|blokace|bloqueo)$", w, re.I)]
        strong = re.compile(STRONG_EN + ("|" + "|".join(re.escape(w) for w in local) if local else ""), re.I)
        return bool(brand_re.search(title) and strong.search(title))
    return False


CATS = {  # check -> (icon, label, hashtag, topic)
    "chain": ("⛓", "On-chain", "onchain", "onchain"), "message": ("✉️", "On-chain message", "message", "onchain"),
    "wallet": ("👛", "Wallet", "wallet", "onchain"), "wallets": ("👛", "Wallets", "wallet", "onchain"),
    "freeze": ("🧊", "Freeze", "freeze", "onchain"), "hacks": ("💥", "Hack", "hack", "onchain"),
    "token": ("📉", "Token", "token", "onchain"), "sites": ("🌐", "Sites", "site", "sites"),
    "register": ("📜", "Licences", "licence", "sites"), "pages": ("🏛", "Regulators", "regulator", "sites"),
    "outlets": ("📰", "News", "news", "news"), "news": ("📰", "News", "news", "news"),
    "forum": ("💬", "Forums", "forum", "forums"), "telegram": ("💬", "Telegram", "telegram", "forums"),
}
GROUP = {"outlets": "news", "news": "news", "telegram": "forum", "wallets": "wallet"}
URL_RE = re.compile(r"https?://\S+")
STOP = set("the and for with from that this into over after says said will have been their about more than news".split())


def esc(s):
    return html.escape(s, quote=False)


def brand_tags(cfg, text):
    tl = text.lower()
    out = []
    for b in cfg.get("forum", {}).get("brands", []):
        if len(b) >= 4 and re.search(r"(?<![a-z0-9])" + re.escape(b.lower()) + r"(?![a-z0-9])", tl):
            tag = re.sub(r"[^a-z0-9]", "", b.lower())
            if tag and tag not in out:
                out.append(tag)
    return out[:3]


def split_text(text):
    links = URL_RE.findall(text)
    body = URL_RE.sub("", text).strip().rstrip(".").strip()
    m = re.match(r"^([A-Z0-9 /&'().-]{6,60}):\s*(.*)$", body, re.S)
    if m:
        return m.group(1).strip().capitalize(), m.group(2).strip(), links
    return body, "", links


def short_line(a, limit=150):
    head, rest, links = split_text(a["text"])
    line = head if not rest else f"{head}: {rest}"
    line = re.sub(r"\s+", " ", line)
    if len(line) > limit:
        line = line[:limit - 1].rsplit(" ", 1)[0] + "…"
    return line, (links[0] if links else "")


def story_sig(a):
    """Signature used to merge the same story across sources and runs."""
    check = GROUP.get(a["check"], a["check"])
    if check == "news":
        title = re.sub(r"^\[[^\]]*\]\s*", "", URL_RE.sub("", a["text"]).lower())
        title = re.sub(r"\s[-|–]\s[^-|–]{2,40}$", "", title)  # drop " - Outlet name"
        words = {w for w in re.findall(r"[^\W\d_]{4,}", title) if w not in STOP}
        return check, words
    return check, {a["key"]}


def same_story(s1, s2):
    if s1[0] != s2[0]:
        return False
    a, b = s1[1], s2[1]
    if not a or not b:
        return False
    return len(a & b) / len(a | b) >= 0.45 if s1[0] == "news" else a == b


def add_to_stories(state, items, t, keep_hours=48):
    """Returns the items that start a new story; others are counted as extra sources."""
    stories = [x for x in state.get("stories", []) if t - parse_iso(x["last"]) < dt.timedelta(hours=keep_hours)]
    new = []
    for it in items:
        sig = story_sig(it)
        match = next((s for s in stories if same_story((s["check"], set(s["sig"])), sig)), None)
        if match:
            match["sources"] += 1
            match["last"] = iso(t)
            match["urgent"] = match["urgent"] or it["urgent"]
            continue
        st = {"check": sig[0], "sig": sorted(sig[1]), "text": it["text"], "key": it["key"], "urgent": it["urgent"],
              "level": it["level"], "first": iso(t), "last": iso(t), "sources": 1}
        stories.append(st)
        new.append(st)
    state["stories"] = stories[-6000:]
    return new


def format_urgent(cfg, s, t):
    icon, label, tag, _ = CATS.get(s["check"], ("•", s["check"], s["check"], "news"))
    head, rest, links = split_text(s["text"])
    lines = [f"🚨 <b>URGENT</b> · {icon} {esc(label)} · {t:%d %b %H:%M} UTC", f"<b>{esc(head[:200])}</b>"]
    if rest:
        lines.append(esc(rest[:600]))
    for u in links[:2]:
        lines.append(f'🔗 <a href="{esc(u)}">{esc(re.sub(r"^https?://(www[.])?", "", u)[:60])}</a>')
    lines.append(" ".join(["#urgent", "#" + tag] + ["#" + x for x in brand_tags(cfg, s["text"])]))
    return "\n".join(lines)


def format_group_list(cfg, stories, per_type, with_sources=True):
    groups = {}
    for s in stories:
        groups.setdefault(s["check"], []).append(s)
    blocks = []
    for check in sorted(groups, key=lambda c: ORDER.index(c) if c in ORDER else 99):
        icon, label, tag, _ = CATS.get(check, ("•", check, check, "news"))
        items = sorted(groups[check], key=lambda s: (not s["urgent"], s["level"] != HIGH, -s["sources"]))
        lines = []
        for s in items[:per_type]:
            line, link = short_line(s)
            mark = "🚨 " if s["urgent"] else ""
            src = f" (+{s['sources'] - 1} sources)" if with_sources and s["sources"] > 1 else ""
            lines.append(f"• {mark}{esc(line)}{src}" + (f' <a href="{esc(link)}">↗</a>' if link else ""))
        more = f"\n<i>+{len(items) - len(lines)} more</i>" if len(items) > len(lines) else ""
        blocks.append(f"{icon} <b>{esc(label)}</b> ({len(items)}) #{tag}\n" + "\n".join(lines) + more)
    return "\n\n".join(blocks)


def send_telegram(http, text, cfg=None, topic=None, silent=False):
    tok, chat = os.environ.get("TELEGRAM_TOKEN"), os.environ.get("TELEGRAM_CHAT_ID")
    if not tok or not chat:
        print("TELEGRAM not configured" + ("" if QUIET else "; message below\n" + text + "\n"))
        return
    thread = ((cfg or {}).get("telegram", {}).get("topics") or {}).get(topic) if topic else None
    chunks, cur = [], ""
    for para in text.split("\n\n"):  # split on blocks so HTML tags never break across messages
        if len(cur) + len(para) + 2 > 3900 and cur:
            chunks.append(cur)
            cur = ""
        cur = (cur + "\n\n" + para) if cur else para[:3900]
    if cur:
        chunks.append(cur)
    for c in chunks:
        data = {"chat_id": chat, "text": c, "parse_mode": "HTML",
                "disable_web_page_preview": "true", "disable_notification": "true" if silent else "false"}
        if thread:
            data["message_thread_id"] = str(thread)
        try:
            r = http.post(f"https://api.telegram.org/bot{tok}/sendMessage", data=data)
            if getattr(r, "status_code", 200) == 429:
                time.sleep(3)
                http.post(f"https://api.telegram.org/bot{tok}/sendMessage", data=data)
        except Exception as e:
            log(f"telegram: {e}")
        time.sleep(0.4)


def deliver(cfg, state, http, alerts, t, dry):
    """Every run: urgent stories one by one (with sound) + one short update with the
    other new stories. Every report_every_hours: a report of every story in that window."""
    tcfg = cfg.get("telegram", {})
    sent = set(state.get("sent", []))
    fresh = []
    for a in alerts:
        if a.key not in sent:
            sent.add(a.key)
            fresh.append({"key": a.key, "check": a.check, "level": a.level, "text": a.text,
                          "urgent": is_urgent(cfg, a), "t": iso(t)})
    state["sent"] = list(sent)[-40000:]
    state["inbox"] = (state.get("inbox", []) + fresh)[-tcfg.get("inbox_size", 5000):]
    new_stories = add_to_stories(state, fresh, t)
    out = []  # (text, topic, silent)
    urgent = [s for s in new_stories if s["urgent"]]
    for s in urgent[:tcfg.get("max_urgent_per_run", 10)]:
        out.append((format_urgent(cfg, s, t), "urgent", False))
    if len(urgent) > tcfg.get("max_urgent_per_run", 10):
        rest = urgent[tcfg.get("max_urgent_per_run", 10):]
        out.append((f"🚨 <b>URGENT</b> · {len(rest)} more\n\n" + format_group_list(cfg, rest, 20, False), "urgent", False))
    others = [s for s in new_stories if not s["urgent"]]
    if others:
        head = f"🛰 <b>Update</b> · {t:%d %b %H:%M} UTC · {len(others)} new"
        out.append((head + "\n\n" + format_group_list(cfg, others, tcfg.get("update_items_per_type", 8), False),
                    "updates", tcfg.get("updates_silent", True)))
    # report every N hours: all stories in the window, merged, urgent first
    every = dt.timedelta(hours=tcfg.get("report_every_hours", 5))
    last = state.get("report_at")
    if not last:
        state["report_at"] = iso(t - dt.timedelta(seconds=1))
    elif t - parse_iso(last) >= every:
        window = [s for s in state.get("stories", []) if parse_iso(s["last"]) > parse_iso(last)]
        state["report_at"] = iso(t)
        n_urg = sum(1 for s in window if s["urgent"])
        meta = state.get("sites_meta", {})
        head = (f"📚 <b>{tcfg.get('report_every_hours', 5)}-hour report</b> · {parse_iso(last) + dt.timedelta(seconds=1):%d %b %H:%M}–{t:%H:%M} UTC\n"
                f"{len(window)} stories, {n_urg} urgent\n"
                f"<i>{meta.get('known', 0)} sites · {len(state.get('wallets', {})) + len(state.get('discovered_wallets', {}))} wallets · "
                f"{state.get('outlets_meta', {}).get('feeds', 0)} outlet feeds · "
                f"{len(state.get('registers', {}).get('anjouan') or {})}+{len(state.get('registers', {}).get('curacao') or {})} licences</i>")
        health = health_lines(state, t)
        if health:
            head += "\n⚠️ <b>Not working:</b> " + esc("; ".join(health))
        urg = [s for s in window if s["urgent"]]
        rest_w = [s for s in window if not s["urgent"]]
        parts = []
        if urg:
            parts.append(f"🚨 <b>URGENT</b> ({len(urg)})\n" + "\n".join(
                "• " + esc(short_line(s)[0]) + (f' <a href="{esc(short_line(s)[1])}">↗</a>' if short_line(s)[1] else "")
                for s in urg[:40]))
        if rest_w:
            parts.append(format_group_list(cfg, rest_w, tcfg.get("report_items_per_type", 30)))
        body = "\n\n".join(parts) if parts else "Nothing new in this window."
        out.append((head + "\n\n" + body + "\n\n#report", "reports", False))
    for text, topic, silent in out:
        if dry:
            print(text + "\n")
        else:
            send_telegram(http, text, cfg, topic, silent)
    return fresh


def _fernet():
    """State is encrypted when RADAR_STATE_KEY is set, so a copy of the cache is
    unreadable without the secret."""
    key = os.environ.get("RADAR_STATE_KEY")
    if not key:
        return None
    import base64
    from cryptography.fernet import Fernet
    return Fernet(base64.urlsafe_b64encode(hashlib.sha256(key.encode()).digest()))


def load_state(path):
    if not os.path.exists(path):
        return {}
    try:
        raw = open(path, "rb").read()
        f = _fernet()
        if f and not raw.lstrip().startswith(b"{"):
            raw = f.decrypt(raw)
        return json.loads(raw)
    except Exception:
        log("state unreadable, starting fresh")
        return {}


def save_state(path, state):
    raw = json.dumps(state, separators=(",", ":")).encode()
    f = _fernet()
    if f:
        raw = f.encrypt(raw)
    tmp = path + ".tmp"
    open(tmp, "wb").write(raw)
    os.replace(tmp, path)


CHECKS = {"forum": check_forum, "freezes": check_freezes, "proposals": check_freeze_proposals, "tokens": check_tokens,
          "wallets": check_wallets, "discover": discover_wallets, "chains": check_chains, "messages": check_messages,
          "hacks": check_hacks, "sites": check_sites, "news": check_news, "outlets": check_outlets,
          "registers": check_registers, "pages": check_pages, "telegram": check_telegram}


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--config", default="config.yaml")
    ap.add_argument("--state", default="state.json")
    ap.add_argument("--only", help="comma list of checks to run")
    ap.add_argument("--dry", action="store_true", help="print instead of sending")
    ap.add_argument("--budget", type=float, default=None, help="seconds for all checks (default from config)")
    args = ap.parse_args()
    cfg = merge_private(yaml.safe_load(open(args.config, encoding="utf-8")))
    state = load_state(args.state)
    http, t = Http(), now()
    budget = Budget(args.budget or cfg.get("run_budget_seconds", 38))
    names = args.only.split(",") if args.only else list(CHECKS)
    alerts = []

    def run(name):
        t0 = time.time()
        try:
            got = CHECKS[name](cfg, state, http, t, budget)
            record_health(state, name, True, t)
        except Exception as e:
            log(f"{name} failed: {type(e).__name__}: {e}")
            record_health(state, name, False, t)
            got = []
        print(f"{name}: {len(got)} alerts in {time.time() - t0:.1f}s")
        return got

    # On the very first run the Anjouan register is loaded before the site sweep,
    # so the sweep knows every licensed domain. After that everything runs in parallel.
    parallel = list(names)
    if "registers" in names and not state.get("registers", {}).get("anjouan"):
        alerts += run("registers")
        parallel.remove("registers")
    with ThreadPoolExecutor(max(1, len(parallel))) as ex:
        for got in ex.map(run, parallel):
            alerts += got
    deliver(cfg, state, http, alerts, t, args.dry and not QUIET)
    if ERRORS:
        print("source errors: " + ", ".join(f"{k} {v}" for k, v in sorted(ERRORS.items())))
    state["last_run"] = iso(t)
    save_state(args.state, state)


if __name__ == "__main__":
    main()
